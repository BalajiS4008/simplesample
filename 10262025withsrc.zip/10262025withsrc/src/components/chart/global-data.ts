export const internationalizationData = [
  { "x": "Timty Castro", "y": 1.23, barColor: '#D8B4F8' },
  { "x": "Luna Amore", "y": 1.54, barColor: '#FF8080' },
  { "x": "Gino Acosta", "y": 1.75, barColor: '#A4B465' },
  { "x": "Railey Cristobal", "y": 2.1, barColor: '#86A7FC' },
  { "x": "Zyra Augerro", "y": 2.25, barColor: '#73946B' },
  { "x": "Hash Brown", "y": 2.54, barColor: '#F2C078' },
  { "x": "Porsche Robles", "y": 2.6, barColor: '#578FCA' },
  { "x": "Thomas Kong", "y": 2.75, barColor: '#F6B53F' },
  { "x": "Corotian Gracia", "y": 3.0, barColor: '#6FAAB0' },
  { "x": "Laura Darris", "y": 3.75, barColor: '#C4C24A' },
];