export const legendPositionData = [
  { x: 'India', y: 4.28, y1: 4.5, barColor: '#D8B4F8' },
  { x: 'Spain', y: 2.9, y1: 3.1, barColor: '#FF8080' },
  { x: 'China', y: 1.53, y1: 1.6, barColor: '#A4B465' },
  { x: 'World', y: 1.52, y1: 1.5, barColor: '#86A7FC' },
  { x: 'Germany', y: 0.82, y1: 0.9, barColor: '#73946B' },
  { x: 'USA', y: 0.18, y1: 0.2, barColor: '#F2C078' },
  { x: 'UK', y: -1.33, y1: -1.5, barColor: '#578FCA' },
]