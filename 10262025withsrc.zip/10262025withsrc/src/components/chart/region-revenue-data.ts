export const barWithTrackData = [
  { region: 'Europe', revenue: 5300000, targetRevenue: 10050000, percentage: 53 },
  { region: 'Americas', revenue: 8700000, targetRevenue: 11500000, percentage: 87 },
  { region: 'Asia', revenue: 5800000, targetRevenue: 8000000, percentage: 58 },
  { region: 'Africa', revenue: 7700000, targetRevenue: 10000000, percentage: 77 }
];