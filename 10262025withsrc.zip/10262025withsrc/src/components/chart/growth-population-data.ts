export const bubbleFirstSeriesCustomData = [
  { x: 'US', xValue: 99.4, y: 2.2, size: 0.312 },
  { x: 'Mexico', xValue: 86.1, y: 4.0, size: 0.115 },
];

export const bubbleSecondSeriesCustomData = [
  { x: 'Germany', xValue: 99, y: 0.7, size: 0.0818 },
  { x: 'Russia', xValue: 99.6, y: 3.4, size: 0.143 },
  { x: 'Netherland', xValue: 79.2, y: 3.9, size: 0.162 },
];

export const bubbleThirdSeriesCustomData = [
  { x: 'China', xValue: 92.2, y: 7.8, size: 1.347 },
  { x: 'India', xValue: 74, y: 6.5, size: 1.241 },
  { x: 'Indonesia', xValue: 90.4, y: 6.0, size: 0.238 },
  { x: 'Japan', xValue: 99, y: 0.2, size: 0.128 },
  { x: 'Philippines', xValue: 92.6, y: 6.6, size: 0.096 },
  { x: 'Hong Kong', xValue: 82.2, y: 3.97, size: 0.7 },
  { x: 'Jordan', xValue: 72.5, y: 4.5, size: 0.7 },
  { x: 'Australia', xValue: 81, y: 3.5, size: 0.21 },
  { x: 'Mongolia', xValue: 66.8, y: 3.9, size: 0.028 },
  { x: 'Taiwan', xValue: 78.4, y: 2.9, size: 0.231 },
];

export const bubbleFourthSeriesCustomData = [
  { x: 'Egypt', xValue: 72, y: 2.0, size: 0.0826 },
  { x: 'Nigeria', xValue: 61.3, y: 1.45, size: 0.162 },
];