export const toggleData = [
  { x: "Iphone", y1: 39.3, y2: 44.6 },
  { x: "Services", y1: 24.2, y2: 27.4 },
  { x: "Mac", y1: 7, y2: 8 },
  { x: "Wearable Accessories", y1: 8.1, y2: 7.4 },
  { x: "Ipad", y1: 7.2, y2: 6.6 },
]