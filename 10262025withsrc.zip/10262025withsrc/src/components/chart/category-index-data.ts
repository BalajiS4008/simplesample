export const chartPoint = [
  { x: 'Myanmar', y: 7.3 },
  { x: 'India', y: 7.9 },
  { x: 'Bangladesh', y: 6.8 },
  { x: 'Cambodia', y: 7.0 },
  { x: 'China', y: 6.9 }
]
export const catergoryIndexData = [
  { x: 'Poland', y: 2.7 },
  { x: 'Australia', y: 2.5 },
  { x: 'Singapore', y: 2.0 },
  { x: 'Canada', y: 1.4 },
  { x: 'Germany', y: 1.8 }
]