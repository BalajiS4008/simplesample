export const paletteData = [
  { year: '2021', apple: 237, xiaomi: 190, oppo: 143 },
  { year: '2022', apple: 226.4, xiaomi: 153.1, oppo: 103.3 },
  { year: '2023', apple: 234.6, xiaomi: 145.9, oppo: 103.1 }
]