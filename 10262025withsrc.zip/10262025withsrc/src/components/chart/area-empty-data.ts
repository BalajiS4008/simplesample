export const areaEmptyData = [
  { x: "Jan", y: 200 }, { x: "Feb", y: 300 }, { x: "Mar", y: 170 },
  { x: "April", y: null }, { x: "May", y: 300 }, { x: "Jun", y: null },
  { x: "July", y: 100 }, { x: "Aug", y: 200 }, { x: "Sep", y: 174 },
  { x: "Oct", y: null }, { x: "Nov", y: null }, { x: "Dec", y: 160 },
];