export const smartAxisLabelData = [
  { x: "India", y: 1.42 },
  { x: "China", y: 1.41},
  { x: "USA", y: 0.33 },
  { x: "Indonesia", y: 0.27 },
  { x: "Pakistan", y: 0.24 },
  { x: "Nigeria", y: 0.22 },
  { x: "Brazil", y: 0.21 },
  { x: "Bangladesh", y: 0.17 }
];