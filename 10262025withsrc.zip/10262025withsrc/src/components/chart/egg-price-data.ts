export const lineLabelData = [
  { x: "Jan", y: 1.93 },
  { x: "Feb", y: 2.01 },
  { x: "Mar", y: 2.05 },
  { x: "April", y: 2.52 },
  { x: "May", y: 2.86 },
  { x: "Jun", y: 2.71 },
  { x: "Jul", y: 2.94 },
  { x: "Aug", y: 3.12 },
  { x: "Sep", y: 2.9 },
  { x: "Oct", y: 3.42 },
  { x: "Nov", y: 3.59 },
  { x: "Dec", y: 4.25 }
];