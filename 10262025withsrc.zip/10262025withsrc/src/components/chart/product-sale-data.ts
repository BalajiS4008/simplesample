export const rectSeriesLiveUpdateData = [
  { x: 'Jewellery', y: 75, color: '#578FCA', barColor: '#D8B4F8' },
  { x: 'Shoes', y: 45, color: '#F2C078', barColor: '#FF8080' },
  { x: 'Footwear', y: 73, color: '#73946B', barColor: '#A4B465' },
  { x: 'Pet Services', y: 53, color: '#98A1EA', barColor: '#86A7FC' },
  { x: 'Business Clothing', y: 85, color: '#FF8080', barColor: '#73946B' },
  { x: 'Office Supplies', y: 68, color: '#D3DE32', barColor: '#F2C078' },
  { x: 'Food', y: 45, color: '#5FDDE5', barColor: '#578FCA' }
];