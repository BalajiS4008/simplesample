export const firstQuarterData = [
  { Month: 'Jan 15', Sales: 10 },
  { Month: 'Jan 31', Sales: 15 },
  { Month: 'Feb 15', Sales: 15 },
  { Month: 'Feb 28', Sales: 20 },
  { Month: 'March 15', Sales: 20 },
  { Month: 'March 31', Sales: 25 },
  { Month: 'March', Sales: null },
];
export const secondQuarterData = [
  { Month: 'Apr 15', Sales: 36 },
  { Month: 'Apr 30', Sales: 48 },
  { Month: 'May 15', Sales: 43 },
  { Month: 'May 31', Sales: 59 },
  { Month: 'Jun 15', Sales: 35 },
  { Month: 'Jun 30', Sales: 50 },
  { Month: 'Jun', Sales: null },
];
export const thirdQuarterData = [
  { Month: 'Jul 15', Sales: 30 },
  { Month: 'Jul 31', Sales: 45 },
  { Month: 'Aug 15', Sales: 30 },
  { Month: 'Aug 31', Sales: 55 },
  { Month: 'Sep 15', Sales: 57 },
  { Month: 'Sep 30', Sales: 60 },
  { Month: 'Sep', Sales: null },
];
export const fourthQuarterData = [
  { Month: 'Oct 15', Sales: 60 },
  { Month: 'Oct 31', Sales: 70 },
  { Month: 'Nov 15', Sales: 70 },
  { Month: 'Nov 30', Sales: 70 },
  { Month: 'Dec 15', Sales: 90 },
  { Month: 'Dec 31', Sales: 100 },
];