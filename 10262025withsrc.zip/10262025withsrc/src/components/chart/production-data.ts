export const columnData = [
  { country: 'Chile', walnuts: 175, almonds: 11.3 },
  { country: 'European Union', walnuts: 140, almonds: 135 },
  { country: 'Turkey', walnuts: 67, almonds: 24 },
  { country: 'India', walnuts: 33, almonds: 42 },
  { country: 'Australia', walnuts: 12, almonds: 154 }
];