export const splineAreaData = [
  { x: new Date(2002, 0, 1), y1: 2.2, y2: 2 },
  { x: new Date(2003, 0, 1), y1: 3.4, y2: 1.7 },
  { x: new Date(2004, 0, 1), y1: 2.8, y2: 1.8 },
  { x: new Date(2005, 0, 1), y1: 1.6, y2: 2.1 },
  { x: new Date(2006, 0, 1), y1: 2.3, y2: 2.3 },
  { x: new Date(2007, 0, 1), y1: 2.5, y2: 1.7 },
  { x: new Date(2008, 0, 1), y1: 2.9, y2: 1.5 },
  { x: new Date(2009, 0, 1), y1: 1.1, y2: 0.5 },
  { x: new Date(2010, 0, 1), y1: 1.4, y2: 1.5 },
  { x: new Date(2011, 0, 1), y1: 1.1, y2: 1.3 }
]