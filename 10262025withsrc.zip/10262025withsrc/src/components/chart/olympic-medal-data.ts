export const legendData = [
  { x: "USA", gold: 40, sliver: 44, bronze: 42 },
  { x: "China", gold: 40, sliver: 27, bronze: 24 },
  { x: "Japan", gold: 20, sliver: 12, bronze: 13 },
  { x: "Australia", gold: 18, sliver: 19, bronze: 16 },
  { x: "France", gold: 16, sliver: 26, bronze: 22 },
  { x: "Netherlands", gold: 15, sliver: 7, bronze: 12 }
]