export const columnPointerData = [
  { market: "China", Dollar: '32,997M', percentage: 18.6 },
  { market: "Mexico", Dollar: '25,518M', percentage: 14.4 },
  { market: "Canada", Dollar: '25,049M', percentage: 14.1 },
  { market: "Japan", Dollar: '14,244M', percentage: 8.0 },
  { market: "EU-27", Dollar: '10,224M', percentage: 5.8 },
  { market: "Korea, south", Dollar: '9,382M', percentage: 5.3 },
  { market: "Rest Of World", Dollar: '59,400M', percentage: 33.6 },
]
