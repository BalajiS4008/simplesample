export const populationData = [
  { country: 'India', population: 1450.935791, male: 748.323427, female: 702.612364 },
  { country: 'China', population: 1419.321278, male: 723.023723, female: 696.297555 },
  { country: 'USA', population: 345.426571, male: 173.551527, female: 171.875044 },
  { country: 'Indonesia', population: 283.487931, male: 142.407931, female: 141.080014 },
  { country: 'Pakistan', population: 251.269164, male: 127.433405, female: 123.835758 }
]