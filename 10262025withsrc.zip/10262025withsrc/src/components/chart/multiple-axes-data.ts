export const multipleAxisData = [
  { x: 'Sun', y1: 35, y2: 30 },
  { x: 'Mon', y1: 40, y2: 28 },
  { x: 'Tue', y1: 80, y2: 29 },
  { x: 'Wed', y1: 70, y2: 30 },
  { x: 'Thu', y1: 65, y2: 33 },
  { x: 'Fri', y1: 55, y2: 32 },
  { x: 'Sat', y1: 50, y2: 34 }
]