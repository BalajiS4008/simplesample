export const stackingBarData = [
  { x: '2020', y1: 466, y2: 261, y3: 1355, total: 2082 },
  { x: '2021', y1: 656, y2: 327, y3: 1340, total: 2323 },
  { x: '2022', y1: 763, y2: 427, y3: 1352, total: 2542 },
  { x: '2023', y1: 886, y2: 584, y3: 1286, total: 2756 }
]