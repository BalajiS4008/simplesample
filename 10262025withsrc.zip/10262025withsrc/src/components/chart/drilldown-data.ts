export const columnDrillDownData: object[] = [
    { x: 'Asia', y: 4778, color: '#EDA9ED' },
    { x: 'Africa', y: 1481, color: '#D0ABEB' },
    { x: 'Europe', y: 746, color: '#B39EF2' },
    { x: 'North America', y: 379, color: '#98A1EA' },
    { x: 'Oceania', y: 46, color: '#81C6F2' }
];