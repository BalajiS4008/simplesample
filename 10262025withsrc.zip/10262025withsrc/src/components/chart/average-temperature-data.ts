export const splineMinimumData = [
  { x: 'Jan', y: 16 },
  { x: 'Feb', y: 18.2 },
  { x: 'Mar', y: 23.1 },
  { x: 'Apr', y: 27.9 },
  { x: 'May', y: 32.2 },
  { x: 'Jun', y: 36.4 },
  { x: 'Jul', y: 39.8 },
  { x: 'Aug', y: 38.4 },
  { x: 'Sep', y: 35.5 },
  { x: 'Oct', y: 29.2 },
  { x: 'Nov', y: 22 },
  { x: 'Dec', y: 17.8 }
];
export const splineData = [
  { x: 'Jan', y: -2.9 },
  { x: 'Feb', y: -3.6 },
  { x: 'Mar', y: -0.6 },
  { x: 'Apr', y: 4.8 },
  { x: 'May', y: 10.2 },
  { x: 'Jun', y: 14.5 },
  { x: 'Jul', y: 17.6 },
  { x: 'Aug', y: 16.5 },
  { x: 'Sep', y: 12 },
  { x: 'Oct', y: 6.5 },
  { x: 'Nov', y: 2 },
  { x: 'Dec', y: -0.9 }
];