export const allSourcesData = [
  { x: new Date(1970, 1, 1), y: 16500 },
  { x: new Date(1975, 1, 1), y: 16000 },
  { x: new Date(1980, 1, 1), y: 15400 },
  { x: new Date(1985, 1, 1), y: 15800 },
  { x: new Date(1990, 1, 1), y: 14000 },
  { x: new Date(1995, 1, 1), y: 10500 },
  { x: new Date(2000, 1, 1), y: 13300 },
  { x: new Date(2005, 1, 1), y: 12800 }
];

export const autosData = [
  { x: new Date(1970, 1, 1), y: 8000 },
  { x: new Date(1975, 1, 1), y: 7600 },
  { x: new Date(1980, 1, 1), y: 6400 },
  { x: new Date(1985, 1, 1), y: 3700 },
  { x: new Date(1990, 1, 1), y: 7200 },
  { x: new Date(1995, 1, 1), y: 2300 },
  { x: new Date(2000, 1, 1), y: 4000 },
  { x: new Date(2005, 1, 1), y: 4800 }
];