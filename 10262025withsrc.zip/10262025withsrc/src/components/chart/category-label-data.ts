export const labelPlacementData = [
  { country: 'USA', y: 194.55 },
  { country: 'Japan', y: 146.2 },
  { country: 'China', y: 65.1 },
  { country: 'France', y: 84.9 },
  { country: 'India', y: 140.1 },
  { country: 'Canada', y: 160.7 },
  { country: 'Brazil', y: 68.4 },
  { country: 'UK', y: 100.2 },
  { country: 'Sweden', y: 162 },
  { country: 'Bangladesh', y: 27.7 }
]