export const lineTransposdData = [
  { x: "Jan", y1: 2, y2: 8 },
  { x: "Mar", y1: 14, y2: 4 },
  { x: "Apr", y1: 27, y2: 15 },
  { x: "Jun", y1: 33, y2: 23 },
  { x: "Aug", y1: 28, y2: 28 },
  { x: "Oct", y1: 16, y2: 12 },
  { x: "Dec", y1: 10, y2: 2 }
];