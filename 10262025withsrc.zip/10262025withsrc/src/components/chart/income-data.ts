export const dataLabelOverviewData = [
  { x: "Italy", y1: 1, y2: 0.4 },
  { x: "USA", y1: 0.5, y2: -0.3 },
  { x: "G7", y1: 0.3, y2: 0 },
  { x: "France", y1: 0.2, y2: 0.1 },
  { x: "Canada", y1: 0.1, y2: 0.4 },
  { x: "Germany", y1: -0.4, y2: 0.3 },
  { x: "UK", y1: -1.3, y2: 0.5 },
];