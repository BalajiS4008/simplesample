export const dataLabelRotationData = [
  { x: 'Brazil', y: 8.6 },
  { x: 'Russian Federation', y: 4.2 },
  { x: 'United States', y: 2.9 },
  { x: 'Canada', y: 2.9 },
  { x: 'China', y: 2.7 },
  { x: 'Columbia', y: 2.4 },
  { x: 'Indonesia', y: 2 },
  { x: 'Peru', y: 1.9 },
  { x: 'India', y: 1.9 },
  { x: 'Venezuela', y: 1.3 },
  { x: 'Congo', y: 1.3 }
];