export const labelCustomData = [
  { country: "Monday", gold: 50, text: 'Monday: 50' },
  { country: "Tuesday", gold: 40, text: 'Tuesday: 40' },
  { country: "Wednesday", gold: 70, text: 'Wednesday: 70' },
  { country: "Thursday", gold: 60, text: 'Thursday: 60' },
  { country: "Friday", gold: 50, text: 'Friday: 50' },
  { country: "Saturday", gold: 40, text: 'Saturday: 40' },
  { country: "Sunday", gold: 40, text: 'Sunday: 40' }
]