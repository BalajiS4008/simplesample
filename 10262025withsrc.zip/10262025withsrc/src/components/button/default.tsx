import { Button } from '@syncfusion/react-buttons';
import './App.css';

export default function App() {
  return (
    <div className="component-section">
      <Button>Default Button</Button>     
    </div>
  );
};