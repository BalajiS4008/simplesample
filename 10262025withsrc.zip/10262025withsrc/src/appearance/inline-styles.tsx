import { Button } from '@syncfusion/react-buttons';

export default function App() {
  return (
    <div className='component-section'>
      <Button style={{ background: 'blue', fontSize: 16 }}>
        Button
      </Button>
    </div>
  );
};