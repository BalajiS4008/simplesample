import { Button } from '@syncfusion/react-buttons';
import './class-styles.css';

export default function App() {
  return (
    <div className='component-section'>
      <Button className="button-green">
        Save
      </Button>
    </div>
  );
};