export { default as bridgeImage } from './bridge.jpg';

